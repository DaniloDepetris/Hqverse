<?php
require_once 'config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Verificar se é uma requisição OPTIONS (preflight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Verificar autenticação do admin (simplificado para exemplo)
function isAdmin() {
    session_start();
    return isset($_SESSION['user_email']) && ($_SESSION['user_email'] === 'admin@hqverso.com' || $_SESSION['user_role'] === 'admin');
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['action'])) {
        if ($_GET['action'] === 'stats') {
            if (!isAdmin()) {
                echo json_encode(['success' => false, 'message' => 'Acesso não autorizado']);
                exit;
            }
            
            try {
                // Estatísticas totais
                $stmt = $pdo->query("SELECT COUNT(*) as total_comics FROM comics");
                $total_comics = $stmt->fetch(PDO::FETCH_ASSOC)['total_comics'];
                
                $stmt = $pdo->query("SELECT COUNT(*) as total_users FROM users");
                $total_users = $stmt->fetch(PDO::FETCH_ASSOC)['total_users'];
                
                $stmt = $pdo->query("SELECT SUM(page_count) as total_pages FROM comics");
                $total_pages = $stmt->fetch(PDO::FETCH_ASSOC)['total_pages'] ?: 0;
                
                $stmt = $pdo->query("SELECT SUM(views) as total_views FROM comics");
                $total_views = $stmt->fetch(PDO::FETCH_ASSOC)['total_views'] ?: 0;
                
                echo json_encode([
                    'success' => true,
                    'stats' => [
                        'total_comics' => $total_comics,
                        'total_users' => $total_users,
                        'total_pages' => $total_pages,
                        'total_views' => $total_views
                    ]
                ]);
            } catch(PDOException $e) {
                echo json_encode(['success' => false, 'message' => 'Erro ao buscar estatísticas: ' . $e->getMessage()]);
            }
        }
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isAdmin()) {
        echo json_encode(['success' => false, 'message' => 'Acesso não autorizado']);
        exit;
    }
    
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add_comic') {
        try {
            // Dados básicos do quadrinho
            $title = $_POST['title'] ?? '';
            $author = $_POST['author'] ?? '';
            $description = $_POST['description'] ?? '';
            $category = $_POST['category'] ?? 'geral';
            $status = $_POST['status'] ?? 'draft';
            $price = floatval($_POST['price'] ?? 0);
            $page_count = intval($_POST['page_count'] ?? 1);
            
            if (empty($title) || empty($author)) {
                throw new Exception('Título e autor são obrigatórios');
            }
            
            // Processar upload da capa
            $cover_path = null;
            if (isset($_FILES['cover']) && $_FILES['cover']['error'] === UPLOAD_ERR_OK) {
                $upload_dir = 'uploads/covers/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }
                
                $cover_name = uniqid() . '_' . basename($_FILES['cover']['name']);
                $cover_path = $upload_dir . $cover_name;
                
                if (!move_uploaded_file($_FILES['cover']['tmp_name'], $cover_path)) {
                    throw new Exception('Erro ao fazer upload da capa');
                }
            }
            
            // Inserir quadrinho no banco
            $stmt = $pdo->prepare("INSERT INTO comics (title, author, description, category, status, price, page_count, cover, is_published) 
                                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $is_published = $status === 'published' ? 1 : 0;
            $stmt->execute([$title, $author, $description, $category, $status, $price, $page_count, $cover_path, $is_published]);
            
            $comic_id = $pdo->lastInsertId();
            
            // Processar upload das páginas
            if (isset($_FILES['pages']) && is_array($_FILES['pages']['name'])) {
                $pages_dir = 'uploads/pages/' . $comic_id . '/';
                if (!is_dir($pages_dir)) {
                    mkdir($pages_dir, 0777, true);
                }
                
                for ($i = 0; $i < count($_FILES['pages']['name']); $i++) {
                    if ($_FILES['pages']['error'][$i] === UPLOAD_ERR_OK) {
                        $page_name = uniqid() . '_' . basename($_FILES['pages']['name'][$i]);
                        $page_path = $pages_dir . $page_name;
                        
                        if (move_uploaded_file($_FILES['pages']['tmp_name'][$i], $page_path)) {
                            $stmt = $pdo->prepare("INSERT INTO comic_pages (comic_id, page_number, image_url) VALUES (?, ?, ?)");
                            $stmt->execute([$comic_id, $i + 1, $page_path]);
                        }
                    }
                }
            }
            
            echo json_encode(['success' => true, 'message' => 'Quadrinho adicionado com sucesso', 'comic_id' => $comic_id]);
            
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    
    elseif ($action === 'delete_comic') {
        $comic_id = $_POST['comic_id'] ?? 0;
        
        try {
            // Deletar páginas primeiro
            $stmt = $pdo->prepare("DELETE FROM comic_pages WHERE comic_id = ?");
            $stmt->execute([$comic_id]);
            
            // Deletar quadrinho
            $stmt = $pdo->prepare("DELETE FROM comics WHERE id = ?");
            $stmt->execute([$comic_id]);
            
            echo json_encode(['success' => true, 'message' => 'Quadrinho deletado com sucesso']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Erro ao deletar quadrinho: ' . $e->getMessage()]);
        }
    }
}
?>