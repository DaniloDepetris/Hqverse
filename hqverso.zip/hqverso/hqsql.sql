-- Criação do Banco de Dados
CREATE DATABASE IF NOT EXISTS `hqsql` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `hqsql`;

-- Tabela de Usuários
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `avatar` VARCHAR(255) DEFAULT NULL,
  `bio` TEXT,
  `role` ENUM('user', 'admin') DEFAULT 'user',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_user_email` (`email`),
  INDEX `idx_user_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Quadrinhos
CREATE TABLE IF NOT EXISTS `comics` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `author` VARCHAR(255) NOT NULL,
  `cover` VARCHAR(255) DEFAULT NULL,
  `description` TEXT,
  `category` VARCHAR(100) DEFAULT 'geral',
  `price` DECIMAL(10,2) DEFAULT 0.00,
  `is_published` BOOLEAN DEFAULT FALSE,
  `is_premium` BOOLEAN DEFAULT FALSE,
  `status` ENUM('draft', 'published', 'archived') DEFAULT 'draft',
  `page_count` INT DEFAULT 0,
  `views` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_comics_title` (`title`),
  INDEX `idx_comics_author` (`author`),
  INDEX `idx_comics_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Páginas dos Quadrinhos
CREATE TABLE IF NOT EXISTS `comic_pages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `comic_id` INT NOT NULL,
  `page_number` INT NOT NULL,
  `image_url` VARCHAR(255) NOT NULL,
  `title` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`comic_id`) REFERENCES `comics`(`id`) ON DELETE CASCADE,
  INDEX `idx_pages_comic` (`comic_id`),
  INDEX `idx_pages_number` (`page_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Progresso de Leitura
CREATE TABLE IF NOT EXISTS `reading_progress` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `comic_id` INT NOT NULL,
  `current_page` INT NOT NULL DEFAULT 1,
  `is_completed` BOOLEAN DEFAULT FALSE,
  `last_read` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `user_comic` (`user_id`, `comic_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`comic_id`) REFERENCES `comics`(`id`) ON DELETE CASCADE,
  INDEX `idx_reading_user` (`user_id`),
  INDEX `idx_reading_comic` (`comic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Favoritos
CREATE TABLE IF NOT EXISTS `favorites` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `comic_id` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `user_comic_fav` (`user_id`, `comic_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`comic_id`) REFERENCES `comics`(`id`) ON DELETE CASCADE,
  INDEX `idx_favorites_user` (`user_id`),
  INDEX `idx_favorites_comic` (`comic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;