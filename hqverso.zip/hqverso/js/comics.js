// comics.js - Funcionalidades específicas da página de quadrinhos

// Estado da aplicação
const comicsState = {
    currentCategory: 'all',
    currentSort: 'newest',
    comics: [],
    filteredComics: [],
    userProgress: {}
};

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    initializeComicsPage();
    setupEventListeners();
    loadComicsData();
});

// Inicializar página de quadrinhos
function initializeComicsPage() {
    checkAuthStatus();
    updateUserInterface();
}

// Verificar status de autenticação
function checkAuthStatus() {
    const user = JSON.parse(localStorage.getItem('currentUser') || sessionStorage.getItem('currentUser'));
    if (!user) {
        window.location.href = 'index.html';
        return;
    }
    updateUserAvatar(user);
}

// Atualizar avatar do usuário
function updateUserAvatar(user) {
    const userAvatar = document.getElementById('userAvatar');
    if (userAvatar) {
        const userName = user.name || user.username || 'Usuário';
        userAvatar.innerHTML = `
            <i class="fas fa-user"></i>
            <span class="user-name">${userName}</span>
            <div class="user-dropdown">
                <a href="perfil.html"><i class="fas fa-user-circle"></i> Meu Perfil</a>
                <a href="detection.html"><i class="fas fa-info-circle"></i> Info Navegador</a>
                <a href="#" id="logoutBtn"><i class="fas fa-sign-out-alt"></i> Sair</a>
            </div>
        `;
        
        // Re-adicionar event listener para logout
        document.getElementById('logoutBtn').addEventListener('click', handleLogout);
    }
}

// Configurar event listeners
function setupEventListeners() {
    // Categorias
    document.querySelectorAll('.category-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const category = this.getAttribute('data-category');
            filterByCategory(category);
        });
    });
    
    // Busca
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', debounce(handleSearch, 300));
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                performSearch();
            }
        });
    }
    
    // Menu mobile
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const searchBar = document.getElementById('searchBar');
    
    if (mobileMenuBtn && searchBar) {
        mobileMenuBtn.addEventListener('click', function() {
            searchBar.classList.toggle('active');
            this.innerHTML = searchBar.classList.contains('active') 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        });
    }
}

// Carregar dados dos quadrinhos
async function loadComicsData() {
    showLoadingState();
    
    try {
        const response = await fetch('api/comics.php?action=all');
        const data = await response.json();
        
        if (data.success) {
            comicsState.comics = data.comics;
            comicsState.filteredComics = data.comics;
            renderComics();
        } else {
            showError('Erro ao carregar quadrinhos: ' + data.message);
        }
    } catch (error) {
        console.error('Erro:', error);
        showError('Erro ao carregar quadrinhos');
        // Carregar dados de fallback
        loadFallbackComics();
    }
}

// Renderizar quadrinhos
function renderComics() {
    renderContinueReading();
    renderRecommendedComics();
    renderAllComics();
    hideLoadingState();
}

// Renderizar "Continuar Lendo"
function renderContinueReading() {
    const container = document.getElementById('continueReading');
    if (!container) return;
    
    const readingComics = comicsState.filteredComics
        .filter(comic => comicsState.userProgress[comic.id])
        .slice(0, 4);
    
    if (readingComics.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-book-open"></i>
                <h3>Nenhuma leitura em andamento</h3>
                <p>Comece a ler um quadrinho para continuar de onde parou</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = readingComics.map(comic => `
        <div class="comic-card" onclick="readComic(${comic.id})">
            ${comicsState.userProgress[comic.id] ? `<div class="comic-badge">Lendo</div>` : ''}
            <img src="${comic.cover || 'https://via.placeholder.com/400x600/333/fff?text=Sem+Capa'}" 
                 alt="${comic.title}" class="comic-cover">
            <div class="comic-info">
                <h3 class="comic-title">${comic.title}</h3>
                <div class="comic-meta">
                    <span class="comic-author">${comic.author || 'Autor desconhecido'}</span>
                    <span class="comic-price">${comic.price ? `R$ ${comic.price}` : 'Grátis'}</span>
                </div>
                ${comicsState.userProgress[comic.id] ? `
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${(comicsState.userProgress[comic.id].current_page / comic.page_count) * 100}%"></div>
                    </div>
                    <div class="reading-progress">
                        Página ${comicsState.userProgress[comic.id].current_page} de ${comic.page_count}
                    </div>
                ` : ''}
            </div>
        </div>
    `).join('');
}

// Renderizar quadrinhos recomendados
function renderRecommendedComics() {
    const container = document.getElementById('recommendedComics');
    if (!container) return;
    
    const recommended = comicsState.filteredComics
        .sort(() => Math.random() - 0.5)
        .slice(0, 4);
    
    container.innerHTML = recommended.map(comic => `
        <div class="comic-card" onclick="readComic(${comic.id})">
            <img src="${comic.cover || 'https://via.placeholder.com/400x600/333/fff?text=Sem+Capa'}" 
                 alt="${comic.title}" class="comic-cover">
            <div class="comic-info">
                <h3 class="comic-title">${comic.title}</h3>
                <div class="comic-meta">
                    <span class="comic-author">${comic.author || 'Autor desconhecido'}</span>
                    <span class="comic-price">${comic.price ? `R$ ${comic.price}` : 'Grátis'}</span>
                </div>
            </div>
        </div>
    `).join('');
}

// Renderizar todos os quadrinhos
function renderAllComics() {
    const container = document.getElementById('allComics');
    if (!container) return;
    
    if (comicsState.filteredComics.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-search"></i>
                <h3>Nenhum quadrinho encontrado</h3>
                <p>Tente alterar os filtros ou termos de busca</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = comicsState.filteredComics.map(comic => `
        <div class="comic-card" onclick="readComic(${comic.id})">
            <img src="${comic.cover || 'https://via.placeholder.com/400x600/333/fff?text=Sem+Capa'}" 
                 alt="${comic.title}" class="comic-cover">
            <div class="comic-info">
                <h3 class="comic-title">${comic.title}</h3>
                <div class="comic-meta">
                    <span class="comic-author">${comic.author || 'Autor desconhecido'}</span>
                    <span class="comic-price">${comic.price ? `R$ ${comic.price}` : 'Grátis'}</span>
                </div>
            </div>
        </div>
    `).join('');
}

// Filtrar por categoria
function filterByCategory(category) {
    // Atualizar botões ativos
    document.querySelectorAll('.category-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`[data-category="${category}"]`).classList.add('active');
    
    comicsState.currentCategory = category;
    
    if (category === 'all') {
        comicsState.filteredComics = comicsState.comics;
    } else {
        comicsState.filteredComics = comicsState.comics.filter(comic => 
            comic.category === category
        );
    }
    
    applySorting();
    renderComics();
}

// Ordenar quadrinhos
function sortComics() {
    const sortSelect = document.getElementById('sortSelect');
    comicsState.currentSort = sortSelect.value;
    applySorting();
    renderComics();
}

function applySorting() {
    switch (comicsState.currentSort) {
        case 'newest':
            comicsState.filteredComics.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
            break;
        case 'oldest':
            comicsState.filteredComics.sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
            break;
        case 'title':
            comicsState.filteredComics.sort((a, b) => a.title.localeCompare(b.title));
            break;
        case 'popular':
            comicsState.filteredComics.sort((a, b) => (b.views || 0) - (a.views || 0));
            break;
    }
}

// Buscar quadrinhos
function performSearch() {
    const searchInput = document.getElementById('searchInput');
    handleSearch(searchInput.value);
}

function handleSearch(query) {
    if (!query.trim()) {
        comicsState.filteredComics = comicsState.comics;
    } else {
        const searchTerm = query.toLowerCase();
        comicsState.filteredComics = comicsState.comics.filter(comic =>
            comic.title.toLowerCase().includes(searchTerm) ||
            (comic.author && comic.author.toLowerCase().includes(searchTerm)) ||
            (comic.description && comic.description.toLowerCase().includes(searchTerm))
        );
    }
    
    applySorting();
    renderComics();
}

// Debounce para busca
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Ler quadrinho
function readComic(comicId) {
    window.location.href = `leitor.html?id=${comicId}`;
}

// Adicionar aos favoritos
function addToFavorites(comicId) {
    // Implementar lógica de favoritos
    alert('Quadrinho adicionado aos favoritos!');
}

// Logout
function handleLogout(e) {
    e.preventDefault();
    if (confirm('Deseja realmente sair?')) {
        localStorage.removeItem('currentUser');
        sessionStorage.removeItem('currentUser');
        window.location.href = 'index.html';
    }
}

// Estados de loading
function showLoadingState() {
    const containers = ['continueReading', 'recommendedComics', 'allComics'];
    containers.forEach(containerId => {
        const container = document.getElementById(containerId);
        if (container) {
            container.innerHTML = `
                <div class="loading">
                    <div class="loading-spinner"></div>
                    Carregando...
                </div>
            `;
        }
    });
}

function hideLoadingState() {
    // Loading states são substituídos pelo conteúdo
}

// Mostrar erro
function showError(message) {
    console.error(message);
    // Poderia mostrar um toast ou modal de erro
}

// Dados de fallback
function loadFallbackComics() {
    comicsState.comics = [
        {
            id: 1,
            title: "Batman: O Cavaleiro das Trevas",
            author: "Frank Miller",
            cover: "https://via.placeholder.com/400x600/333/fff?text=Batman",
            description: "A obra-prima que redefiniu o Batman",
            category: "super-heroi",
            price: 29.90,
            page_count: 200,
            views: 1500,
            created_at: "2023-01-15"
        },
        {
            id: 2,
            title: "Watchmen",
            author: "Alan Moore",
            cover: "https://via.placeholder.com/400x600/555/fff?text=Watchmen",
            description: "Graphic novel revolucionária",
            category: "graphic-novel",
            price: 39.90,
            page_count: 180,
            views: 1200,
            created_at: "2023-02-20"
        },
        {
            id: 3,
            title: "Maus",
            author: "Art Spiegelman",
            cover: "https://via.placeholder.com/400x600/777/fff?text=Maus",
            description: "História em quadrinhos sobre o Holocausto",
            category: "graphic-novel",
            price: 34.90,
            page_count: 160,
            views: 900,
            created_at: "2023-03-10"
        }
    ];
    
    comicsState.filteredComics = comicsState.comics;
    renderComics();
}

// Atualizar interface do usuário
function updateUserInterface() {
    // Implementar atualizações específicas da UI se necessário
}