// script.js - Integração completa com backend

// Verificar se usuário está logado
function checkAuth() {
    fetch('auth.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action: 'check' })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success && data.user) {
            updateUIForLoggedInUser(data.user);
        } else {
            updateUIForGuest();
        }
    })
    .catch(error => {
        console.error('Erro ao verificar autenticação:', error);
    });
}

// Atualizar UI para usuário logado
function updateUIForLoggedInUser(user) {
    const loginBtn = document.querySelector('.btn-outline');
    if (loginBtn) {
        loginBtn.textContent = `Olá, ${user.name}`;
        loginBtn.onclick = () => {
            window.location.href = 'comics.html';
        };
    }
    
    // Adicionar botão de logout se não existir
    if (!document.getElementById('logoutBtn')) {
        const logoutBtn = document.createElement('button');
        logoutBtn.id = 'logoutBtn';
        logoutBtn.className = 'btn btn-outline';
        logoutBtn.textContent = 'Sair';
        logoutBtn.style.marginLeft = '10px';
        logoutBtn.onclick = logout;
        
        const headerActions = document.querySelector('.user-menu');
        if (headerActions) {
            headerActions.appendChild(logoutBtn);
        }
    }
}

// Atualizar UI para visitante
function updateUIForGuest() {
    const loginBtn = document.querySelector('.btn-outline');
    if (loginBtn) {
        loginBtn.textContent = 'Entrar';
        loginBtn.onclick = () => toggleModal('authModal', true);
    }
    
    // Remover botão de logout se existir
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.remove();
    }
}

// Função de logout
function logout() {
    fetch('auth.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action: 'logout' })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.location.href = 'index.html';
        }
    })
    .catch(error => {
        console.error('Erro ao fazer logout:', error);
    });
}

// Modal de Login/Cadastro
function toggleModal(modalId, show = true) {
    const modal = document.getElementById(modalId);
    modal.style.display = show ? 'flex' : 'none';
    document.body.style.overflow = show ? 'hidden' : 'auto';
}

// Fechar modal ao clicar fora
window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
        toggleModal('authModal', false);
    }
});

// Trocar entre abas
document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
        const tabId = tab.getAttribute('data-tab');

        // Remover classe active de todas as tabs e contents
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

        // Adicionar classe active na tab e content selecionados
        tab.classList.add('active');
        document.getElementById(tabId).classList.add('active');
    });
});

// Formulário de login
document.getElementById('loginForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    if (!email || !password) {
        alert('Por favor, preencha todos os campos');
        return;
    }

    fetch('auth.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            action: 'login',
            email: email,
            password: password
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Login realizado com sucesso!');
            toggleModal('authModal', false);
            window.location.href = 'comics.html';
        } else {
            alert(data.message);
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        alert('Erro ao fazer login');
    });
});

// Formulário de cadastro
document.getElementById('signupForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('signupName').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    const confirmPassword = document.getElementById('signupConfirmPassword').value;

    if (!name || !email || !password || !confirmPassword) {
        alert('Por favor, preencha todos os campos');
        return;
    }

    if (password !== confirmPassword) {
        alert('As senhas não coincidem!');
        return;
    }

    if (password.length < 6) {
        alert('A senha deve ter pelo menos 6 caracteres');
        return;
    }

    fetch('auth.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            action: 'signup',
            name: name,
            email: email,
            password: password
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Conta criada com sucesso! Faça login.');
            document.getElementById('signupForm').reset();
            document.querySelector('[data-tab="login"]').click();
        } else {
            alert(data.message);
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        alert('Erro ao criar conta');
    });
});

// Menu mobile
const mobileMenuBtn = document.getElementById('mobileMenuBtn');
const searchBar = document.getElementById('searchBar');

if (mobileMenuBtn && searchBar) {
    mobileMenuBtn.addEventListener('click', function() {
        searchBar.classList.toggle('active');
        
        if (searchBar.classList.contains('active')) {
            mobileMenuBtn.innerHTML = '<i class="fas fa-times"></i>';
        } else {
            mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
        }
    });
}

// Tema claro/escuro
const themeToggle = document.getElementById('themeToggle');

// Verificar tema salvo
const savedTheme = localStorage.getItem('theme');
if (savedTheme === 'light') {
    document.body.classList.add('light-theme');
    themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
} else {
    themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
}

themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('light-theme');
    
    if (document.body.classList.contains('light-theme')) {
        localStorage.setItem('theme', 'light');
        themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
    } else {
        localStorage.setItem('theme', 'dark');
        themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
    }
});

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    checkAuth();
});