<?php
// install.php - Executar apenas uma vez
header('Content-Type: text/plain; charset=utf-8');

try {
    $conn = new PDO("mysql:host=localhost", "root", "");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Criar banco de dados
    $conn->exec("CREATE DATABASE IF NOT EXISTS `hqsql` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    echo "Banco de dados criado com sucesso.\n";
    
    // Usar o banco
    $conn->exec("USE `hqsql`");
    
    // Ler e executar o arquivo SQL
    $sql = file_get_contents('hqsql.sql');
    
    // Dividir as queries para execução individual
    $queries = explode(';', $sql);
    
    foreach ($queries as $query) {
        $query = trim($query);
        if (!empty($query)) {
            $conn->exec($query);
        }
    }
    
    echo "Tabelas criadas com sucesso!\n";
    
    // Criar usuários de exemplo
    $password = password_hash('admin123', PASSWORD_DEFAULT);
    $conn->exec("INSERT IGNORE INTO users (username, email, password, role) VALUES 
                ('admin', 'admin@hqverso.com', '$password', 'admin'),
                ('usuario', 'usuario@teste.com', '$password', 'user')");
    
    echo "Usuários de exemplo criados:\n";
    echo "Admin: admin@hqverso.com / admin123\n";
    echo "Usuário: usuario@teste.com / admin123\n";
    
    // Criar alguns quadrinhos de exemplo
    $conn->exec("INSERT IGNORE INTO comics (title, author, description, category, price, is_published, page_count) VALUES 
                ('Batman: O Cavaleiro das Trevas', 'Frank Miller', 'A obra-prima que redefiniu o Batman', 'super-heroi', 29.90, 1, 200),
                ('Watchmen', 'Alan Moore', 'Graphic novel revolucionária', 'graphic-novel', 39.90, 1, 180),
                ('Maus', 'Art Spiegelman', 'História em quadrinhos sobre o Holocausto', 'graphic-novel', 34.90, 1, 160)");
    
    echo "Quadrinhos de exemplo adicionados!\n";
    echo "Instalação concluída com sucesso!\n";
    
} catch(PDOException $e) {
    die("ERRO: " . $e->getMessage());
}
?>