<?php
require_once '../config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['action'])) {
        if ($_GET['action'] === 'all') {
            // Buscar todos os quadrinhos
            try {
                $stmt = $pdo->query("SELECT * FROM comics WHERE is_published = 1 ORDER BY created_at DESC");
                $comics = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                echo json_encode(['success' => true, 'comics' => $comics]);
            } catch(PDOException $e) {
                echo json_encode(['success' => false, 'message' => 'Erro ao buscar quadrinhos: ' . $e->getMessage()]);
            }
        }
        elseif ($_GET['action'] === 'single' && isset($_GET['id'])) {
            // Buscar um quadrinho específico
            try {
                $stmt = $pdo->prepare("SELECT * FROM comics WHERE id = ? AND is_published = 1");
                $stmt->execute([$_GET['id']]);
                $comic = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($comic) {
                    // Buscar páginas do quadrinho
                    $stmtPages = $pdo->prepare("SELECT * FROM comic_pages WHERE comic_id = ? ORDER BY page_number");
                    $stmtPages->execute([$_GET['id']]);
                    $pages = $stmtPages->fetchAll(PDO::FETCH_ASSOC);
                    
                    $comic['pages'] = $pages;
                    echo json_encode(['success' => true, 'comic' => $comic]);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Quadrinho não encontrado']);
                }
            } catch(PDOException $e) {
                echo json_encode(['success' => false, 'message' => 'Erro ao buscar quadrinho: ' . $e->getMessage()]);
            }
        }
        elseif ($_GET['action'] === 'category' && isset($_GET['category'])) {
            // Buscar por categoria
            try {
                $category = '%' . $_GET['category'] . '%';
                $stmt = $pdo->prepare("SELECT * FROM comics WHERE category LIKE ? AND is_published = 1 ORDER BY created_at DESC");
                $stmt->execute([$category]);
                $comics = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                echo json_encode(['success' => true, 'comics' => $comics]);
            } catch(PDOException $e) {
                echo json_encode(['success' => false, 'message' => 'Erro ao buscar por categoria: ' . $e->getMessage()]);
            }
        }
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (isset($data['action'])) {
        if ($data['action'] === 'save_progress') {
            // Salvar progresso de leitura
            session_start();
            if (!isset($_SESSION['user_id'])) {
                echo json_encode(['success' => false, 'message' => 'Usuário não logado']);
                exit;
            }
            
            $user_id = $_SESSION['user_id'];
            $comic_id = $data['comic_id'];
            $current_page = $data['current_page'];
            
            try {
                $stmt = $pdo->prepare("INSERT INTO reading_progress (user_id, comic_id, current_page) 
                                      VALUES (?, ?, ?) 
                                      ON DUPLICATE KEY UPDATE current_page = ?, last_read = NOW()");
                $stmt->execute([$user_id, $comic_id, $current_page, $current_page]);
                
                echo json_encode(['success' => true, 'message' => 'Progresso salvo']);
            } catch(PDOException $e) {
                echo json_encode(['success' => false, 'message' => 'Erro ao salvar progresso: ' . $e->getMessage()]);
            }
        }
    }
}
?>