<?php
require_once 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (isset($data['action'])) {
        if ($data['action'] === 'login') {
            $email = $data['email'];
            $password = $data['password'];
            
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['username'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_role'] = $user['role'];
                
                echo json_encode(['success' => true, 'user' => [
                    'id' => $user['id'],
                    'name' => $user['username'],
                    'email' => $user['email'],
                    'role' => $user['role']
                ]]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Credenciais inválidas']);
            }
        }
        elseif ($data['action'] === 'signup') {
            $name = $data['name'];
            $email = $data['email'];
            $password = password_hash($data['password'], PASSWORD_DEFAULT);
            
            try {
                $stmt = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
                $stmt->execute([$name, $email, $password]);
                
                echo json_encode(['success' => true, 'message' => 'Usuário criado com sucesso']);
            } catch(PDOException $e) {
                echo json_encode(['success' => false, 'message' => 'Erro ao criar usuário: ' . $e->getMessage()]);
            }
        }
        elseif ($data['action'] === 'logout') {
            session_destroy();
            echo json_encode(['success' => true, 'message' => 'Logout realizado com sucesso']);
        }
        elseif ($data['action'] === 'check') {
            if (isset($_SESSION['user_id'])) {
                echo json_encode(['success' => true, 'user' => [
                    'id' => $_SESSION['user_id'],
                    'name' => $_SESSION['user_name'],
                    'email' => $_SESSION['user_email'],
                    'role' => $_SESSION['user_role']
                ]]);
            } else {
                echo json_encode(['success' => false]);
            }
        }
    }
}
?>