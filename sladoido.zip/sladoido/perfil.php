<?php
require_once 'includes_auth.php';

if(!$auth->isLoggedIn()) {
    header("Location: login.php");
    exit();
}

$user_data = $auth->getUserData($_SESSION['user_id']);
$initial = strtoupper(substr($user_data['username'], 0, 1));

$success = '';
$error = '';
$active_tab = 'profile';

// Processar edição de perfil
if($_POST && isset($_POST['update_profile'])) {
    $username = $_POST['username'] ?? '';
    $bio = $_POST['bio'] ?? '';
    
    $result = $auth->updateProfile($_SESSION['user_id'], $username, $user_data['email'], $bio);
    if($result === true) {
        $success = "Perfil atualizado com sucesso!";
        $user_data = $auth->getUserData($_SESSION['user_id']);
        $initial = strtoupper(substr($user_data['username'], 0, 1));
    } else {
        $error = $result;
    }
}

// Processar alteração de senha
if($_POST && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    if($new_password !== $confirm_password) {
        $error = "As novas senhas não coincidem!";
    } elseif(strlen($new_password) < 6) {
        $error = "A nova senha deve ter pelo menos 6 caracteres!";
    } else {
        $result = $auth->changePassword($_SESSION['user_id'], $current_password, $new_password);
        if($result === true) {
            $success = "Senha alterada com sucesso!";
        } else {
            $error = $result;
        }
    }
    $active_tab = 'password';
}

// Processar remoção de avatar
if($_POST && isset($_POST['remove_avatar'])) {
    $result = $auth->removeAvatar($_SESSION['user_id']);
    if($result === true) {
        $success = "Foto de perfil removida com sucesso!";
        $user_data = $auth->getUserData($_SESSION['user_id']);
    } else {
        $error = "Erro ao remover foto de perfil!";
    }
    $active_tab = 'avatar';
}

// Processar exclusão de conta
if($_POST && isset($_POST['delete_account'])) {
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    $result = $auth->changePassword($_SESSION['user_id'], $confirm_password, $confirm_password);
    if($result === true) {
        $result = $auth->deleteUserAccount($_SESSION['user_id'], $_SESSION['user_id']);
        if($result === true) {
            header("Location: login.php?message=conta_excluida");
            exit();
        } else {
            $error = $result;
        }
    } else {
        $error = "Senha incorreta!";
    }
    $active_tab = 'delete';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meu Perfil - HQ Verso</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); color: #fff; min-height: 100vh; padding: 20px; }
        .container { max-width: 1000px; margin: 0 auto; }
        header { display: flex; justify-content: space-between; align-items: center; padding: 20px 0; margin-bottom: 30px; }
        .logo { font-size: 28px; font-weight: 800; color: #e94560; text-decoration: none; }
        .back-btn { color: #e94560; text-decoration: none; font-weight: 600; display: flex; align-items: center; gap: 8px; }
        .profile-container { background: rgba(26, 26, 46, 0.8); border-radius: 10px; padding: 30px; box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3); }
        
        .profile-header { display: flex; align-items: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 2px solid #e94560; }
        .profile-avatar { width: 120px; height: 120px; border-radius: 50%; background: #e94560; display: flex; align-items: center; justify-content: center; font-size: 48px; font-weight: bold; margin-right: 25px; position: relative; overflow: hidden; border: 3px solid #e94560; }
        .profile-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .avatar-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.7); display: flex; align-items: center; justify-content: center; opacity: 0; transition: opacity 0.3s ease; cursor: pointer; }
        .profile-avatar:hover .avatar-overlay { opacity: 1; }
        
        .profile-info h2 { font-size: 24px; margin-bottom: 5px; }
        .email-info { color: #e94560; font-weight: 500; margin-bottom: 5px; }
        
        .profile-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: rgba(15, 52, 96, 0.3); padding: 20px; border-radius: 8px; text-align: center; }
        .stat-number { font-size: 28px; font-weight: 700; color: #e94560; margin-bottom: 5px; }
        .stat-label { font-size: 14px; opacity: 0.8; }
        
        .tabs { display: flex; margin-bottom: 30px; border-bottom: 1px solid rgba(255, 255, 255, 0.2); }
        .tab { padding: 15px 30px; cursor: pointer; font-weight: 600; border-bottom: 3px solid transparent; }
        .tab.active { color: #e94560; border-bottom: 3px solid #e94560; }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 500; }
        .form-group input, .form-group textarea { width: 100%; padding: 12px; border: 1px solid rgba(255, 255, 255, 0.2); border-radius: 5px; background: rgba(255, 255, 255, 0.05); color: #fff; font-size: 16px; }
        .form-group input:focus, .form-group textarea:focus { outline: none; border-color: #e94560; }
        .form-group textarea { height: 100px; resize: vertical; }
        
        .password-toggle { position: relative; }
        .password-toggle i { position: absolute; right: 15px; top: 40px; cursor: pointer; }
        
        .btn { padding: 12px 25px; border-radius: 5px; font-weight: 600; cursor: pointer; border: none; font-size: 16px; text-decoration: none; display: inline-block; }
        .btn-primary { background: #e94560; color: white; }
        .btn-primary:hover { background: #d8345f; }
        .btn-outline { background: transparent; border: 2px solid #e94560; color: #e94560; }
        .btn-danger { background: #dc3545; color: white; width: 100%; }
        .btn-sm { padding: 8px 15px; font-size: 14px; }
        
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 5px; text-align: center; font-weight: 500; }
        .alert-success { background: rgba(76, 175, 80, 0.2); border: 1px solid #4caf50; color: #4caf50; }
        .alert-error { background: rgba(233, 69, 96, 0.2); border: 1px solid #e94560; color: #e94560; }
        
        .upload-area { border: 2px dashed #e94560; border-radius: 10px; padding: 30px; text-align: center; margin-bottom: 20px; cursor: pointer; }
        .upload-area:hover { background: rgba(233, 69, 96, 0.1); }
        
        @media (max-width: 768px) {
            .profile-header { flex-direction: column; text-align: center; }
            .profile-avatar { margin: 0 auto 15px; }
            .tabs { flex-direction: column; }
            .tab { text-align: center; }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <a href="comics.php" class="logo">HQ VERSO</a>
            <a href="comics.php" class="back-btn"><i class="fas fa-arrow-left"></i> Voltar</a>
        </header>
        
        <?php if($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if($error): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="profile-container">
            <!-- CABEÇALHO DO PERFIL -->
            <div class="profile-header">
                <div class="profile-avatar">
                    <?php if($user_data['avatar'] && file_exists($user_data['avatar'])): ?>
                        <img src="<?php echo $user_data['avatar']; ?>" alt="Avatar">
                    <?php else: ?>
                        <span><?php echo $initial; ?></span>
                    <?php endif; ?>
                    <div class="avatar-overlay" onclick="document.getElementById('avatarInput').click()">
                        <i class="fas fa-camera"></i>
                    </div>
                </div>
                <div class="profile-info">
                    <h2><?php echo htmlspecialchars($user_data['username']); ?></h2>
                    <div class="email-info">
                        <i class="fas fa-envelope"></i> <?php echo htmlspecialchars($user_data['email']); ?>
                    </div>
                    <p>Membro desde: <?php echo date('d/m/Y', strtotime($user_data['created_at'])); ?></p>
                    <?php if($user_data['avatar']): ?>
                        <form method="POST" style="margin-top: 10px;">
                            <input type="hidden" name="remove_avatar" value="1">
                            <button type="submit" class="btn btn-outline btn-sm" onclick="return confirm('Remover foto de perfil?')">
                                <i class="fas fa-trash"></i> Remover Foto
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>

            <!-- INPUT OCULTO PARA UPLOAD -->
            <input type="file" id="avatarInput" accept="image/*" style="display: none;">

            <!-- ESTATÍSTICAS -->
            <div class="profile-stats">
                <div class="stat-card"><div class="stat-number">24</div><div class="stat-label">Quadrinhos Lidos</div></div>
                <div class="stat-card"><div class="stat-number">8</div><div class="stat-label">Favoritos</div></div>
                <div class="stat-card"><div class="stat-number">15</div><div class="stat-label">Dias de Leitura</div></div>
                <div class="stat-card"><div class="stat-number">3</div><div class="stat-label">Reviews</div></div>
            </div>
            
            <!-- ABAS -->
            <div class="tabs">
                <div class="tab <?php echo $active_tab === 'profile' ? 'active' : ''; ?>" data-tab="profile">
                    <i class="fas fa-user-edit"></i> Editar Perfil
                </div>
                <div class="tab <?php echo $active_tab === 'avatar' ? 'active' : ''; ?>" data-tab="avatar">
                    <i class="fas fa-camera"></i> Foto do Perfil
                </div>
                <div class="tab <?php echo $active_tab === 'password' ? 'active' : ''; ?>" data-tab="password">
                    <i class="fas fa-lock"></i> Alterar Senha
                </div>
                <div class="tab <?php echo $active_tab === 'delete' ? 'active' : ''; ?>" data-tab="delete">
                    <i class="fas fa-trash-alt"></i> Excluir Conta
                </div>
            </div>
            
            <!-- ABA 1: EDITAR PERFIL -->
            <div class="tab-content <?php echo $active_tab === 'profile' ? 'active' : ''; ?>" id="profile">
                <form method="POST">
                    <input type="hidden" name="update_profile" value="1">
                    
                    <div class="form-group">
                        <label for="username">Nome de Usuário</label>
                        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user_data['username']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Email</label>
                        <div style="padding: 12px; background: rgba(255,255,255,0.05); border-radius: 5px; color: #e94560;">
                            <i class="fas fa-lock"></i> <?php echo htmlspecialchars($user_data['email']); ?>
                            <small style="opacity: 0.7;"> (não pode ser alterado)</small>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="bio">Biografia</label>
                        <textarea id="bio" name="bio" placeholder="Conte um pouco sobre você..."><?php echo htmlspecialchars($user_data['bio'] ?? ''); ?></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Salvar Alterações
                    </button>
                </form>
            </div>
            
            <!-- ABA 2: FOTO DO PERFIL -->
            <div class="tab-content <?php echo $active_tab === 'avatar' ? 'active' : ''; ?>" id="avatar">
                <div class="upload-area" onclick="document.getElementById('avatarInput').click()">
                    <i class="fas fa-cloud-upload-alt"></i>
                    <h3>Clique para escolher uma foto</h3>
                    <p>Formatos: JPG, PNG, GIF, WebP (Máx. 5MB)</p>
                </div>
                
                <div style="text-align: center; margin-top: 20px;">
                    <h4 style="margin-bottom: 15px; color: #e94560;">Foto Atual</h4>
                    <div class="profile-avatar" style="margin: 0 auto; width: 100px; height: 100px; font-size: 36px;">
                        <?php if($user_data['avatar'] && file_exists($user_data['avatar'])): ?>
                            <img src="<?php echo $user_data['avatar']; ?>" alt="Avatar atual">
                        <?php else: ?>
                            <span><?php echo $initial; ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- ABA 3: ALTERAR SENHA -->
            <div class="tab-content <?php echo $active_tab === 'password' ? 'active' : ''; ?>" id="password">
                <form method="POST">
                    <input type="hidden" name="change_password" value="1">
                    
                    <div class="form-group password-toggle">
                        <label for="current_password">Senha Atual</label>
                        <input type="password" id="current_password" name="current_password" required>
                        <i class="fas fa-eye" onclick="togglePassword('current_password', this)"></i>
                    </div>
                    
                    <div class="form-group password-toggle">
                        <label for="new_password">Nova Senha</label>
                        <input type="password" id="new_password" name="new_password" required>
                        <i class="fas fa-eye" onclick="togglePassword('new_password', this)"></i>
                    </div>
                    
                    <div class="form-group password-toggle">
                        <label for="confirm_password">Confirmar Nova Senha</label>
                        <input type="password" id="confirm_password" name="confirm_password" required>
                        <i class="fas fa-eye" onclick="togglePassword('confirm_password', this)"></i>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-key"></i> Alterar Senha
                    </button>
                </form>
            </div>
            
            <!-- ABA 4: EXCLUIR CONTA -->
            <div class="tab-content <?php echo $active_tab === 'delete' ? 'active' : ''; ?>" id="delete">
                <div class="alert alert-error" style="text-align: left;">
                    <h3 style="margin-bottom: 10px;"><i class="fas fa-exclamation-triangle"></i> Atenção!</h3>
                    <p>Esta ação é <strong>irreversível</strong>. Todos os seus dados serão permanentemente removidos.</p>
                </div>
                
                <form method="POST">
                    <input type="hidden" name="delete_account" value="1">
                    
                    <div class="form-group password-toggle">
                        <label for="confirm_password_delete">Digite sua senha para confirmar:</label>
                        <input type="password" id="confirm_password_delete" name="confirm_password" required>
                        <i class="fas fa-eye" onclick="togglePassword('confirm_password_delete', this)"></i>
                    </div>
                    
                    <button type="submit" class="btn btn-danger" onclick="return confirm('Tem certeza que deseja excluir sua conta permanentemente?')">
                        <i class="fas fa-trash-alt"></i> Excluir Minha Conta
                    </button>
                </form>
            </div>
            
            <!-- LINKS EXTRAS -->
            <div style="display: flex; gap: 15px; margin-top: 30px;">
                <a href="detection.html" class="btn btn-outline">
                    <i class="fas fa-info-circle"></i> Info do Navegador
                </a>
                <a href="logout.php" class="btn btn-outline">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </a>
            </div>
        </div>
    </div>

    <script>
        // SISTEMA DE ABAS
        document.querySelectorAll('.tab').forEach(tab => {
            tab.addEventListener('click', function() {
                // Remove active de todas as tabs
                document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
                // Adiciona active na tab clicada
                this.classList.add('active');
                
                // Mostra o conteúdo correspondente
                const tabName = this.getAttribute('data-tab');
                document.querySelectorAll('.tab-content').forEach(content => {
                    content.classList.remove('active');
                });
                document.getElementById(tabName).classList.add('active');
            });
        });

        // UPLOAD DE AVATAR
        document.getElementById('avatarInput').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const formData = new FormData();
                formData.append('avatar', file);

                // Faz o upload
                fetch('upload_avatar.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        alert('Foto de perfil atualizada com sucesso!');
                        location.reload(); // Recarrega a página
                    } else {
                        alert('Erro: ' + data.message);
                    }
                })
                .catch(error => {
                    alert('Erro no upload. Tente novamente.');
                });
            }
        });

        // ALTERNAR VISIBILIDADE DA SENHA
        function togglePassword(inputId, icon) {
            const input = document.getElementById(inputId);
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>