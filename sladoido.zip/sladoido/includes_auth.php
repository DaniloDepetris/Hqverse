<?php
session_start();
require_once 'config_database.php';

class Auth {
    private $conn;
    private $table = 'users';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // ATUALIZADA: Função register com verificação de banimento
    public function register($username, $email, $password) {
        try {
            // VERIFICAÇÃO DE BANIMENTO - Verificar primeiro se está banido
            $banned = $this->isUserBanned($email, $username);
            if($banned) {
                $banned_date = date('d/m/Y H:i', strtotime($banned['banned_at']));
                return "Este email ou nome de usuário está permanentemente banido. Motivo: " . 
                       ($banned['reason'] ?: 'Não especificado') . 
                       " (Banido em: $banned_date)";
            }

            // Verificar se usuário ou email já existem
            $query = "SELECT id FROM " . $this->table . " WHERE username = :username OR email = :email";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":username", $username);
            $stmt->bindParam(":email", $email);
            $stmt->execute();

            if($stmt->rowCount() > 0) {
                return "Usuário ou email já cadastrado!";
            }

            // Inserir novo usuário
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $query = "INSERT INTO " . $this->table . " 
                     (username, email, password, created_at) 
                     VALUES (:username, :email, :password, NOW())";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":username", $username);
            $stmt->bindParam(":email", $email);
            $stmt->bindParam(":password", $hashed_password);

            if($stmt->execute()) {
                return true;
            }
            return "Erro ao cadastrar usuário!";

        } catch(PDOException $exception) {
            return "Erro: " . $exception->getMessage();
        }
    }

    public function login($email, $password) {
        try {
            $query = "SELECT id, username, email, password, role FROM " . $this->table . " 
                     WHERE email = :email";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":email", $email);
            $stmt->execute();

            if($stmt->rowCount() == 1) {
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if(password_verify($password, $user['password'])) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['role'] = $user['role'];
                    return true;
                }
            }
            return "Email ou senha incorretos!";

        } catch(PDOException $exception) {
            return "Erro: " . $exception->getMessage();
        }
    }

    public function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }

    public function isAdmin() {
        return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
    }

    public function logout() {
        session_destroy();
        header("Location: login.php");
        exit();
    }

    public function getUserData($user_id) {
        try {
            $query = "SELECT id, username, email, avatar, bio, role, created_at 
                     FROM " . $this->table . " WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":id", $user_id);
            $stmt->execute();

            if($stmt->rowCount() == 1) {
                return $stmt->fetch(PDO::FETCH_ASSOC);
            }
            return false;

        } catch(PDOException $exception) {
            return false;
        }
    }

    public function getAllUsers() {
        try {
            $query = "SELECT id, username, email, role, created_at FROM users ORDER BY created_at DESC";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $exception) {
            return [];
        }
    }

    // CORREÇÃO: Função updateProfile corrigida
    public function updateProfile($user_id, $username, $email, $bio = '') {
        try {
            // Verificar se o username ou email já existem (excluindo o usuário atual)
            $query = "SELECT id FROM " . $this->table . " 
                     WHERE (username = :username OR email = :email) AND id != :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":username", $username);
            $stmt->bindParam(":email", $email);
            $stmt->bindParam(":id", $user_id);
            $stmt->execute();

            if($stmt->rowCount() > 0) {
                return "Username ou email já está em uso!";
            }

            // Atualizar perfil - CORREÇÃO: adicionado updated_at
            $query = "UPDATE " . $this->table . " 
                     SET username = :username, email = :email, bio = :bio, updated_at = NOW() 
                     WHERE id = :id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":username", $username);
            $stmt->bindParam(":email", $email);
            $stmt->bindParam(":bio", $bio);
            $stmt->bindParam(":id", $user_id);

            if($stmt->execute()) {
                // Atualizar sessão
                $_SESSION['username'] = $username;
                $_SESSION['email'] = $email;
                return true;
            }
            return "Erro ao atualizar perfil!";

        } catch(PDOException $exception) {
            return "Erro: " . $exception->getMessage();
        }
    }

    // CORREÇÃO: Função changePassword corrigida
    public function changePassword($user_id, $current_password, $new_password) {
        try {
            // Buscar usuário
            $query = "SELECT id, password FROM " . $this->table . " WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":id", $user_id);
            $stmt->execute();

            if($stmt->rowCount() == 1) {
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                // Verificar senha atual
                if(password_verify($current_password, $user['password'])) {
                    // Atualizar senha
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $query = "UPDATE " . $this->table . " 
                             SET password = :password, updated_at = NOW() 
                             WHERE id = :id";
                    
                    $stmt = $this->conn->prepare($query);
                    $stmt->bindParam(":password", $hashed_password);
                    $stmt->bindParam(":id", $user_id);

                    if($stmt->execute()) {
                        return true;
                    }
                    return "Erro ao atualizar senha!";
                } else {
                    return "Senha atual incorreta!";
                }
            }
            return "Usuário não encontrado!";

        } catch(PDOException $exception) {
            return "Erro: " . $exception->getMessage();
        }
    }

    // FUNÇÃO: Excluir conta do usuário
    public function deleteUserAccount($user_id, $current_user_id = null) {
        try {
            // Verificar se é o próprio usuário ou um admin
            if($current_user_id && $current_user_id != $user_id) {
                $current_user = $this->getUserData($current_user_id);
                if($current_user['role'] !== 'admin') {
                    return "Você não tem permissão para excluir esta conta!";
                }
            }

            // Iniciar transação para garantir que todas as exclusões sejam feitas
            $this->conn->beginTransaction();

            // Excluir dados relacionados nas outras tabelas
            $tables = [
                'reactions', 'posts', 'topics', 'comic_comments', 'reviews', 
                'favorites', 'reading_progress', 'user_library', 'transactions',
                'comic_collaborators', 'comic_drafts', 'user_uploads',
                'comic_categories', 'comic_pages', 'comics'
            ];

            foreach($tables as $table) {
                // Para comics, só excluir se o usuário for o autor
                if($table === 'comics') {
                    $query = "DELETE FROM $table WHERE author_id = :user_id";
                } else {
                    // Verificar se a tabela tem user_id ou author_id
                    $columns = $this->getTableColumns($table);
                    if(in_array('user_id', $columns)) {
                        $query = "DELETE FROM $table WHERE user_id = :user_id";
                    } elseif(in_array('author_id', $columns)) {
                        $query = "DELETE FROM $table WHERE author_id = :user_id";
                    } else {
                        continue;
                    }
                }
                
                $stmt = $this->conn->prepare($query);
                $stmt->bindParam(":user_id", $user_id);
                $stmt->execute();
            }

            // Finalmente excluir o usuário
            $query = "DELETE FROM users WHERE id = :user_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":user_id", $user_id);
            $stmt->execute();

            $this->conn->commit();

            // Se o usuário está excluindo a própria conta, fazer logout
            if($current_user_id == $user_id) {
                session_destroy();
            }

            return true;

        } catch(PDOException $exception) {
            $this->conn->rollBack();
            return "Erro ao excluir conta: " . $exception->getMessage();
        }
    }

    // Função auxiliar para obter colunas da tabela
    private function getTableColumns($table) {
        $query = "SHOW COLUMNS FROM $table";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
        return $columns;
    }

    // NOVA FUNÇÃO: Verificar se usuário está banido
    public function isUserBanned($email, $username = '') {
        try {
            $query = "SELECT id, email, username, reason, banned_at, banned_by 
                     FROM banned_users 
                     WHERE email = :email OR username = :username";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":email", $email);
            $stmt->bindParam(":username", $username);
            $stmt->execute();

            if($stmt->rowCount() > 0) {
                return $stmt->fetch(PDO::FETCH_ASSOC);
            }
            return false;

        } catch(PDOException $exception) {
            return false;
        }
    }

    // NOVA FUNÇÃO: Banir usuário permanentemente
    public function banUser($user_id, $banned_by, $reason = '') {
        try {
            // Primeiro obter dados do usuário a ser banido
            $user_data = $this->getUserData($user_id);
            if(!$user_data) {
                return "Usuário não encontrado!";
            }

            // Verificar se já está banido
            $already_banned = $this->isUserBanned($user_data['email'], $user_data['username']);
            if($already_banned) {
                return "Este usuário já está banido!";
            }

            // Inserir na tabela de banidos
            $query = "INSERT INTO banned_users (email, username, reason, banned_by, is_permanent) 
                     VALUES (:email, :username, :reason, :banned_by, TRUE)";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":email", $user_data['email']);
            $stmt->bindParam(":username", $user_data['username']);
            $stmt->bindParam(":reason", $reason);
            $stmt->bindParam(":banned_by", $banned_by);

            if($stmt->execute()) {
                // Agora excluir a conta do usuário
                return $this->deleteUserAccount($user_id, $banned_by);
            }
            return "Erro ao banir usuário!";

        } catch(PDOException $exception) {
            return "Erro: " . $exception->getMessage();
        }
    }

    // NOVA FUNÇÃO: Pesquisar usuários
    public function searchUsers($search_term) {
        try {
            $query = "SELECT id, username, email, role, created_at,
                             (SELECT COUNT(*) FROM comics WHERE author_id = users.id) as comics_count
                      FROM users 
                      WHERE username LIKE :search OR email LIKE :search
                      ORDER BY username";
            $stmt = $this->conn->prepare($query);
            $search_term = "%$search_term%";
            $stmt->bindParam(":search", $search_term);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $exception) {
            return [];
        }
    }

    // NOVA FUNÇÃO: Obter lista de usuários banidos
    public function getBannedUsers() {
        try {
            $query = "SELECT bu.*, u.username as banned_by_name 
                     FROM banned_users bu 
                     LEFT JOIN users u ON bu.banned_by = u.id 
                     ORDER BY bu.banned_at DESC";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $exception) {
            return [];
        }
    }

    // NOVA FUNÇÃO: Obter todos os usuários para admin
    public function getAllUsersForAdmin() {
        try {
            $query = "SELECT id, username, email, role, created_at,
                             (SELECT COUNT(*) FROM comics WHERE author_id = users.id) as comics_count
                      FROM users 
                      ORDER BY created_at DESC";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $exception) {
            return [];
        }
    }
// NOVA FUNÇÃO: Atualizar avatar (sistema de arquivos)
public function updateAvatar($user_id, $avatar_path, $file_name, $file_size, $mime_type) {
    try {
        // Primeiro remover avatar anterior se existir
        $user_data = $this->getUserData($user_id);
        if($user_data['avatar'] && file_exists($user_data['avatar'])) {
            unlink($user_data['avatar']);
        }

        $query = "UPDATE users SET avatar = :avatar, 
                 avatar_file_name = :file_name, 
                 avatar_file_size = :file_size, 
                 avatar_mime_type = :mime_type,
                 avatar_updated_at = NOW() 
                 WHERE id = :user_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":avatar", $avatar_path);
        $stmt->bindParam(":file_name", $file_name);
        $stmt->bindParam(":file_size", $file_size);
        $stmt->bindParam(":mime_type", $mime_type);
        $stmt->bindParam(":user_id", $user_id);

        if($stmt->execute()) {
            return true;
        }
        return false;

    } catch(PDOException $exception) {
        return false;
    }
}

// NOVA FUNÇÃO: Remover avatar
public function removeAvatar($user_id) {
    try {
        // Primeiro obter o caminho do avatar atual
        $user_data = $this->getUserData($user_id);
        $current_avatar = $user_data['avatar'];
        
        // Remover arquivo físico se existir
        if($current_avatar && file_exists($current_avatar)) {
            unlink($current_avatar);
        }
        
        // Atualizar banco de dados
        $query = "UPDATE users SET avatar = NULL, 
                 avatar_file_name = NULL, 
                 avatar_file_size = NULL, 
                 avatar_mime_type = NULL,
                 avatar_updated_at = NOW() 
                 WHERE id = :user_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":user_id", $user_id);

        if($stmt->execute()) {
            return true;
        }
        return false;

    } catch(PDOException $exception) {
        return false;
    }
}
} // FIM DA CLASSE Auth

$auth = new Auth();
?>